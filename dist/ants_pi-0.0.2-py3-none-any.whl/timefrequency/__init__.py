# __init__.py
from .fft import FFT
from .multitaper import Multitaper
from .wavelet import Wavelet