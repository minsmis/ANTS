# __init__.py
from .plots import Plots